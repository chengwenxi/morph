#!/bin/bash

VERSION=v0.10.0
SGX=0
EXPECTED_ARCH="x86_64 arm64 aarch64 x64"

TIMESTAMP=$(date +"%Y%m%d%H%M%S")
RANDOM_STRING=$(printf "%04x" $RANDOM)
CONTAINER_NAME="cobo-tss-node-$TIMESTAMP-$RANDOM_STRING"

BASE_PATH=$(dirname "$0")
BASE_PATH=$( (cd "$BASE_PATH" && pwd))

[ -f "$BASE_PATH/.env" ] && source "$BASE_PATH/.env"

IMAGE_BASE="${IMAGE_BASE:-coboglobal/tss-node}"
ACCESS_USER="${ACCESS_USER-coborolecustomer}"
ACCESS_TOKEN="${ACCESS_TOKEN-dckr_pat_H5h3R6qLOyIl5V-R2ETXVJtdElo}"

if [ "$SGX" == "1" ]; then
    if [ -n "$VERSION" ]; then
        IMAGE="${IMAGE:-$IMAGE_BASE:$VERSION-sgx}"
    else
        IMAGE="${IMAGE:-$IMAGE_BASE:sgx}"
    fi
else
    if [ -n "$VERSION" ]; then
        IMAGE="${IMAGE:-$IMAGE_BASE:$VERSION}"
    else
        IMAGE="${IMAGE:-$IMAGE_BASE:latest}"
    fi
fi

CONFIGS_DIR="${CONFIGS_DIR:-$BASE_PATH/configs}"
DB_DIR="${DB_DIR:-$BASE_PATH/db}"
LOGS_DIR="${LOGS_DIR:-$BASE_PATH/logs}"
RECOVERY_DIR="${RECOVERY_DIR:-$BASE_PATH/recovery}"

# setup colors
if [ -t 1 ]; then
    ncolors=$(tput colors)
    if [ -n "$ncolors" ] && [ "$ncolors" -ge 8 ]; then
        bold="$(tput bold)"
        underline="$(tput smul)"
        standout="$(tput smso)"
        normal="$(tput sgr0)"
        red="$(tput setaf 1)"
        green="$(tput setaf 2)"
    fi
fi

is_sudo() {
    [ "$EUID" -eq 0 ]
}

check_sys() {
    check_arch || exit 1
    check_tools
    check_docker
    ret=$?
    [ "$ret" == 1 ] && { install_docker || exit 1; }
    [ "$ret" == 2 ] && { restart_docker_engine || exit 1; }
    [ "$ret" == 3 ] && { no_docker_permission || exit 1; }

    if [ "$SGX" == 1 ]; then
        check_sgx_driver || install_sgx_driver || exit 1
    fi
    check_image || pull_image || exit 1
}

check_arch() {
    arch=$(uname -m)
    if ! [[ "$EXPECTED_ARCH" =~ (^|[[:space:]])"$arch"($|[[:space:]]) ]]; then
        echo "${red}Wrong architecture. ${normal}"
        echo
        echo "Your machine architecture is $arch, but this package only support $EXPECTED_ARCH."
        echo "Please use another package that match your architecture."
        echo
        return 1
    fi
    return 0
}

check_tools() {
    local missing_tools=()

    for tool in openssl awk xxd; do
        if ! command -v "$tool" > /dev/null; then
            missing_tools+=("$tool")
        fi
    done

    if [ ${#missing_tools[@]} -ne 0 ]; then
        echo "Error: The following required tools are not installed:"
        for tool in "${missing_tools[@]}"; do
            echo "  - $tool"
        done
        echo "Please install them and try again."
        exit 1
    fi
}

check_docker() {
    [ "$reduced" != 1 ] && echo -n "Checking docker engine ... "
    if ! which docker >/dev/null; then
        echo "${red}Docker command not found${normal}"
        return 1
    fi
    server_version="$(docker version --format '{{.Server.Version}}' 2>/dev/null)"
    if [ "$?" != 0 ]; then
        if is_sudo; then
            echo "${red}Docker engine not started${normal}"
            return 2
        else
            echo "${red}Docker engine not accessible${normal}"
            return 3
        fi
    fi
    [ "$reduced" != 1 ] && echo "${bold}OK${normal}, version: ${server_version}"
    return 0
}

install_docker() {
    if [ "$(uname -s)" == "Darwin" ]; then
        echo
        echo "Please install docker desktop: "
        echo "    ${underline}https://www.docker.com/products/docker-desktop/${normal}"
        echo
        exit 1
    fi

    echo
    echo "Please refer to the following page to install docker: "
    echo "    ${underline}https://docs.docker.com/engine/install/ubuntu/#install-using-the-repository${normal}"
    echo
    if [ "$reduced" == 1 ]; then
        echo "Run a full check with command 'sudo $0 status'."
        exit 1
    fi
    if ! is_sudo; then
        echo "If you run me with 'sudo', I can help you with the installation."
        echo "For now, I'm going to stop here. Please try again after you have docker installed."
        exit 1
    fi
    read -p "Would you like to install docker using ${underline}https://get.docker.com${normal} script? (y/n) " ans
    if [ "$ans" != y ]; then
        echo "Well, I'm going to stop here. Please try again after you have docker installed."
        exit 1
    fi
    curl -fsSL https://get.docker.com -o "$BASE_PATH/get-docker.sh"
    bash "$BASE_PATH/get-docker.sh" || exit 1
    rm -f "$BASE_PATH/get-docker.sh"
    service docker restart || exit 1
    check_docker
}

restart_docker_engine() {
    if [ "$reduced" == 1 ]; then
        echo "Run a full check with command 'sudo $0 status'."
        exit 1
    fi
    if ! is_sudo; then
        echo
        echo "Restart docker engine with command 'sudo service docker restart'."
        echo "If you run me with 'sudo', I can help you with the installation."
        echo "For now, I'm going to stop here. Please try again after you have docker engine running."
        exit 1
    fi
    echo "Going to restart docker engine..."
    service docker restart || exit 1
    check_docker
}

no_docker_permission() {
    echo
    echo "Either docker engine is down, or you don't have permission to access it."
    echo "Please run me with 'sudo', or check the docs on how to use docker without sudo."
    exit 1
}

check_sgx_driver() {
    [ "$reduced" != 1 ] && echo -n "Checking SGX driver ... "
    err=0
    [ -c /dev/sgx_enclave ] || err=1
    [ -c /dev/sgx_provision ] || err=1
    if [ "$err" != 0 ]; then
        echo "${red}SGX driver not available${normal}"
        return 1
    fi
    [ "$reduced" != 1 ] && echo "${bold}OK${normal}"
    return 0
}

install_sgx_driver() {
    lsb_dist="$(. /etc/os-release && echo "$ID")"
    [ "$lsb_dist" == "ubuntu" ] && dist_codename="$(. /etc/lsb-release && echo "$DISTRIB_CODENAME")" &&
        dist_version="$(. /etc/lsb-release && echo "$DISTRIB_RELEASE")"

    echo
    echo "Please refer to the official guide from Intel to install SGX driver: "
    echo "    ${underline}https://download.01.org/intel-sgx/latest/dcap-latest/linux/docs/Intel_SGX_SW_Installation_Guide_for_Linux.pdf${normal}"
    echo
    echo "Basically, the choices are:"
    echo " 1. (recommended) Upgrade to kernel version 5.11 or higher."
    [ "$dist_codename" == "focal" ] && echo "    Since you are running Ubuntu 20.04, you can upgrade to HWE kernel:" &&
        echo "         sudo apt install --install-recommends linux-generic-hwe-20.04"
    echo " 2. Install DCAP driver from Intel, without upgrading kernel."
    echo " 3. If you are using Cloud VM, such as Aliyun or Azure with SGX support. You can contact your cloud provider about how to install SGX driver."
    echo
    if [ "$reduced" == 1 ]; then
        echo "Run a full check with command 'sudo $0 status'."
        exit 1
    fi
    if [ "$lsb_dist" != ubuntu ]; then
        echo "For now, I'm going to stop here. Please try again after you have SGX driver installed."
        exit 1
    fi
    if ! is_sudo; then
        echo "If you run me with 'sudo', I can help you with the installation."
        echo "For now, I'm going to stop here. Please try again after you have SGX driver installed."
        exit 1
    fi
    read -p "Would you like to install DCAP SGX driver? (y/n) " ans
    if [ "$ans" != y ]; then
        echo "Well, I'm going to stop here. Please try again after you have SGX driver installed."
        exit 1
    fi
    apt-get install -y build-essential ocaml automake autoconf libtool wget python libssl-dev dkms cpuid || exit 1

    echo -n "Checking SGX1 Support ... "
    support_sgx1=$(cpuid -1 | grep SGX1\ supported | cut -d "=" -f 2 | xargs)
    if [ "$support_sgx1" != "true" ]; then
        echo "${red}not supported${normal}"
        echo
        echo "It seems your hardware does not support SGX, or SGX is not enabled in BIOS."
        exit 1
    fi
    echo "${bold}OK${normal}"
    echo -n "Checking SGX FlexLC Support ... "
    support_flc=$(cpuid -1 | grep SGX_LC\: | cut -d "=" -f 2 | xargs)
    if [ "$support_flc" != "true" ]; then
        echo "${red}not supported${normal}"
        echo
        echo "It seems your hardware does not support FlexLC, or FlexLC is not enabled in BIOS."
        echo "FlexLC is required."
        exit 1
    fi
    echo "${bold}OK${normal}"

    distro_name=${lsb_dist}${dist_version}-server
    version=1.41
    curl -fsSL https://download.01.org/intel-sgx/latest/dcap-latest/linux/distro/${distro_name}/sgx_linux_x64_driver_${version}.bin \
        -o "$BASE_PATH/sgx_linux_x64_driver_${version}.bin" || exit 1
    bash "$BASE_PATH/sgx_linux_x64_driver_${version}.bin" || exit 1
    rm -f "$BASE_PATH/sgx_linux_x64_driver_${version}.bin"
    check_sgx_driver
}

check_image() {
    [ "$reduced" != 1 ] && echo -n "Checking container image ... "
    image_id=$(docker inspect --format='{{.Id}}' "$IMAGE" 2>/dev/null)
    if [ -z "$image_id" ]; then
        echo "${red}Image not found:${normal} $IMAGE"
        return 1
    fi
    exp=$(cat "$BASE_PATH/.image_id" 2>/dev/null)
    if [ "$image_id" != "$exp" ]; then
        echo "${red}Image is not ready${normal}"
        return 2
    fi
    [ "$reduced" != 1 ] && echo "${bold}OK${normal}, id: $image_id"
    return 0
}

pull_image() {
    echo
    echo "Going to pull container image $IMAGE ..."
    echo
    if [ -n "$ACCESS_USER" ] && [ -n "$ACCESS_TOKEN" ]; then
        docker login -u "$ACCESS_USER" -p "$ACCESS_TOKEN" 2>/dev/null || exit 1
    fi
    docker pull "$IMAGE" || exit 1

    # now we check the public souce whether the image is valid
    ### TODO...

    docker inspect --format='{{.Id}}' "$IMAGE" >"$BASE_PATH/.image_id" || exit 1
    check_image
}

running_container_status() {
    r=$(docker ps --filter label=com.cobo.tss-node.daemon=0 \
        --format='{{.ID}}\t{{.Label "com.cobo.tss-node.cmd"}}\t{{.Status}}\t{{.Label "com.cobo.tss-node.base-path"}}')
    if [ -n "$r" ]; then
        echo "${bold}Warning:${normal} There are some containers running transient commands. They shouldn't be running more than a few seconds."
        echo
        echo -e "CONTAINER ID\tCOMMAND\tSTATUS\t\tBASE PATH"
        echo -e "$r"
        echo
        read -p "Do you want to stop and remove these containers? (y/n) " ans
        if [ "$ans" == y ]; then
            # we have to keep dummy in read, otherwise read returns a whole line
            echo -e "$r" | while read id dummy; do
                echo -n "Stop and remove $id ... "
                if docker stop "$id" >/dev/null && docker rm "$id" >/dev/null; then
                    echo "${bold}OK${normal}"
                else
                    echo "${red}Fail${normal}"
                fi
            done
        fi
    fi

    r=$(get_daemon_container)
    if [ -z "$r" ]; then
        echo "Checking TSS Node daemon ... ${red}not running${normal}"
        echo
        echo "Please use '$0 start' to start the daemon. "
        echo "Please use '$0 init' if the TSS Node is not initialized yet."
        echo
        return 1
    fi
    echo -e "$r" | while read id; do
        if [ "$(docker container inspect -f '{{.State.Running}}' "$id")" != "true" ]; then
            status="${red}Stopped${normal}"
        else
            status="${green}Running${normal}"
        fi
        echo "================================================================="
        echo "Recent logs from TSS Node daemon container ${bold}${id}${normal} ($status)"
        echo "-----------------------------------------------------------------"
        echo "..."
        docker logs --tail 5 "$id"
        echo
    done

    n=$(echo -e "$r" | wc -l)
    if [ "$n" -gt 1 ]; then
        echo "${bold}Warning:${normal} There are more than one daemon containers."
        echo "Use 'docker stop \$id' or 'docker remove \$id' to stop or remove the unexpected ones."
        echo "Use '$0 stop' to stop all daemon containers."
    fi
}

get_daemon_container() {
    docker ps -a --filter label=com.cobo.tss-node.daemon=1 --filter label=com.cobo.tss-node.base-path="$BASE_PATH" --format='{{.ID}}'
}

can_work_with_current_user() {
    if [ -d "$CONFIGS_DIR" ]; then
        [ -r "$CONFIGS_DIR" ] || return 1
    else
        [ -w "$BASE_PATH" ] || return 1
    fi
    if [ -d "$DB_DIR" ]; then
        if [ -f "$DB_DIR/secrets.db" ]; then
            [ -w "$DB_DIR/secrets.db" ] || return 1
        else
            [ -w "$DB_DIR" ] || return 1
        fi
    else
        [ -w "$BASE_PATH" ] || return 1
    fi
    if [ -d "$LOGS_DIR" ]; then
        [ -w "$LOGS_DIR" ] || return 1
    else
        [ -w "$BASE_PATH" ] || return 1
    fi
    if [ -d "$RECOVERY_DIR" ]; then
        [ -w "$RECOVERY_DIR" ] || return 1
    else
        [ -w "$BASE_PATH" ] || return 1
    fi
    return 0
}

# check if an element is in an array
contains_element() {
  local element
  for element in "${@:2}"; do [[ "$element" == "$1" ]] && return 0; done
  return 1
}

run_payload() {
    configs_map=$CONFIGS_DIR:/app/configs
    db_map=$DB_DIR:/app/db
    logs_map=$LOGS_DIR:/app/logs
    recovery_map=$RECOVERY_DIR:/app/recovery
    dir_map=(-v "$configs_map" -v "$db_map" -v "$logs_map" -v "$recovery_map")
    [ "$SGX" == 1 ] && device_map="--device=/dev/sgx_enclave:/dev/sgx/enclave --device=/dev/sgx_provision:/dev/sgx/provision"

    if [ -n "$USERGROUP" ]; then
        user="--user $USERGROUP"
    elif [ "$(id -u)" -eq 0 ]; then
        user=
    elif can_work_with_current_user; then
        mkdir -p -m 700 "$CONFIGS_DIR" "$DB_DIR" "$LOGS_DIR" "$RECOVERY_DIR"
        user="--user $(id -u):$(id -g)"
    else
        user=
        tips_run_non_root
    fi

    # Check if --password-segment is present
    if contains_element "--password-segment" "$@"; then
        password_segment=true
    else
        password_segment=false
    fi

    # Check --docker-network
    args=( "$@" )
    index=0
    while [[ $index -lt ${#args[@]} ]]; do
        if [[ "${args[index]}" == "--docker-network" ]]; then
            if [[ $((index+1)) -lt ${#args[@]} ]]; then
                DOCKER_NETWORK=${args[index+1]}
                unset 'args[index]'
                unset 'args[index+1]'
                break
            fi
        fi
        ((index++))
    done

    if [ "$is_daemon" -ne 1 ]; then
        # do not deamonize
        run_flags="--env TSSNODE_DISABLE_TERM_PASSWORD_INPUT= --rm"
        docker run $device_map "${dir_map[@]}" -it \
            $run_flags \
            $user \
            --name $CONTAINER_NAME \
            --label com.cobo.tss-node.base-path="$BASE_PATH" \
            --label com.cobo.tss-node.daemon="$is_daemon" \
            --label com.cobo.tss-node.cmd="$1" \
            "$IMAGE" "${@:1}"
    elif [ "$need_password" -ne 1 ]; then
        # daemonize but don't need password (we don't have this case)
        echo "Unsupported run case: daemonize without password."
        return 1
    else
        # daemonize and need password
        r=$(get_daemon_container)
        if [ -n "$r" ]; then
            echo "TSS Node daemon is running in the background."
            echo
            echo "Please use '$0 status' to check status."
            echo "Please use '$0 log' to check logs."
            echo "Please use '$0 stop' to stop it."
            echo
            return 1
        fi

        code=$(openssl rand -hex 10)
        run_flags="--env TSSNODE_PASSWORD_HTTP_CODE=$code -p 127.0.0.1::53333 -d"
        if [[ -n "$DOCKER_NETWORK" ]]; then
            run_flags+=" --network $DOCKER_NETWORK"
            echo "Docker network: ${DOCKER_NETWORK}"
        fi

        container_id=$(docker run $device_map "${dir_map[@]}" -it \
            $run_flags \
            $user \
            --name $CONTAINER_NAME \
            --label com.cobo.tss-node.base-path="$BASE_PATH" \
            --label com.cobo.tss-node.daemon="$is_daemon" \
            --label com.cobo.tss-node.cmd="$1" \
            "$IMAGE" "${args[@]}")

        if [ "$?" -ne 0 ]; then
            echo """
Cannot start container. Please check with '$0 status' or 'docker ps -a'.
"""
            return 1
        fi

        echo "Container started: $container_id"
        # get portmap like '127.0.0.1:49153'
        portmap=$(docker port "$container_id" 53333)

        trap "cancel_run $container_id" EXIT
        input_password "$container_id" "$code" "$portmap" "$password_segment"
        trap - EXIT

        sleep 1
        isrunning=$(docker container inspect -f '{{.State.Running}}' "$container_id")
        if [ "$isrunning" != "true" ]; then
            docker logs "$container_id"
            docker rm "$container_id"
            return 1
        fi

        trap tips_before_exit EXIT
        docker logs -f "$container_id"
    fi
}

input_password() {
    name=$1
    code=$2
    urlbase="http://$3"
    password_segment=$4

    echo -n "Wait a few seconds ."
    i=0
    while [ "X$response" != "XPONGOK" ]; do
        echo -n .
        sleep 1
        isrunning=$(docker container inspect -f '{{.State.Running}}' "$name")
        [ "$isrunning" != "true" ] && return 1
        [ "$i" -gt 25 ] && return 1
        response=$(curl -s "$urlbase/ping")
        i=$(($i + 1))
    done
    echo

    if [ "$password_segment" = "true" ] || ([ -n "$PASSWORD_SEGMENT" ] && [ "$PASSWORD_SEGMENT" -eq 1 ] 2>/dev/null); then
        # enable password segment
        segments_count=0
        entire_password=
        read -p "Please enter the number of password segments (between 1 and 10): " segments_count
        if [[ $segments_count -lt 1 || $segments_count -gt 10 ]]; then
            echo "Invalid number of segments. Please enter a number between 1 and 10."
            exit 1
        fi

        for (( i=1; i<=segments_count; i++ ))
        do
            read -p "Type password segment $i: " -s segment_password
            echo
            if [ -z "$segment_password" ]; then
                  echo "Empty password is not allowed"
                  exit 1
            fi

            initial_hash=$(echo -n "$segment_password" | openssl dgst -sha256 | awk '{print $2}')
            double_hash=$(echo -n "$initial_hash" | xxd -r -p | openssl dgst -sha256 | awk '{print $2}')
            echo "The double sha256 hash of password segment $i is: 0x${double_hash:0:8}...${double_hash:56:8}"

            entire_password+="$segment_password"
            segment_password=""
        done
        password="$entire_password"
        entire_password=""
    else
        read -p "Type password: " -s password
        echo
    fi

    password_length=$(echo -n "$password" | wc -c)

    if [ "$password_length" -gt 320 ]; then
      echo "Error: Password length "$password_length" exceeds the maximum limit of 320 characters."
      exit 1
    fi

    enc=$(echo -n "$password" | openssl aes-256-cbc -a -k "$code" -md sha256 2>/dev/null)
    response=$(curl -s -H "Content-Type: text/plain" --data "$enc" "$urlbase/passwd")

    password=""
    enc=""
    if [ "X$response" == "XOKOKOK" ]; then
        return 0
    else
        echo "Unexpected error. ($response)"
        return 4
    fi

    return 0
}

cancel_run() {
    echo
    echo "Cleaning up ..."
    docker stop "$1"
    docker rm "$1"
}

help() {
    b=$(basename "$0")
    echo """
Usage:   $b COMMAND [OPTIONS]

(Script version: $VERSION)

A wrapper script to manage Cobo TSS Node containerized deployment.
Most commands are passed to TSS Node executable within a container.
Some additional commands are handled by this script.

Commands handled by this script:
  status    Check and show status of the current system.
            We'll first check the dependencies, namely docker and SGX
            driver (depending on whether you use SGX). If not met, you will
            be adviced to install the dependencies.
            Then we'll check if the container images was built. If not,
            we will build it.
            Then we'll check if any instances of TSS Node is running.
  log       Show docker logs of running TSS Node service.
  stop      Stop and remove TSS Node container.
  pull      Pull (and potentially upgrade) the container image from online
            registry.

Commands passed to TSS Node:
  init, info, start
  version, help, ...

Examples:
  $b init     To initialize TSS Node parameters and service container.
  $b start    To start TSS Node service container in the background.

To get more help, check out our docs, or contact us.
    """
    exit 0
}

tips_before_exit() {
    echo """

TSS Node will keep running in a background container.
Use '$0 log' to check logs, or '$0 stop' to stop it."""
}

tips_run_non_root() {
    echo """
Note: This version of TSS Node can run with non-root user. However, your db file and
other related files / directories are not accessable by the current user (probably those
files were created by root user with a previous version of TSS Node). So we have to continue
with root user this time.

In order to run as non-root user, you can use 'chown' to manually change owner and group
of all existing related files. """
}

command_stop() {
    get_daemon_container | while read id; do
        echo -n "Stop and remove $id ... "
        if docker stop "$id" >/dev/null && docker rm "$id" >/dev/null; then
            echo "${bold}OK${normal}"
        else
            echo "${red}Fail${normal}"
        fi
    done
}

command_logs() {
    r=$(get_daemon_container)
    n=$(echo -e "$r" | wc -l)
    if [ "$n" -gt 1 ]; then
        echo "${bold}Warning:${normal} There are more than one daemon containers. I don't know which one to show logs."
        echo "Please use '$0 status' to check the recent logs of these containers, and stop the unexpected ones using 'docker stop'"
        return 1
    fi
    if [ "$(docker container inspect -f '{{.State.Running}}' "$r")" != "true" ]; then
        docker logs --tail 100 "$r"
        echo
        echo "TSS Node is stopped. "
        echo "Please use '$0 stop' then '$0 start' to re-start it. "
        echo
    else
        trap tips_before_exit EXIT
        docker logs --tail 100 -f "$r"
    fi
}

command_pull() {
    pull_image
}

[ -z "$1" ] && help

case "$1" in
status)
    reduced=0 check_sys
    echo
    running_container_status
    ;;

stop) command_stop ;;
log | logs) command_logs ;;
pull) command_pull ;;

*)
    [ "$1" == "start" ] && is_daemon=1 || is_daemon=0
    [ "$1" == "info" ] || [ "$1" == "init" ] || [ "$1" == "start" ] && need_password=1 || need_password=0
    reduced=1

    check_sys

    run_payload "${@:1}"
    ;;

esac
